# Icons

Place icon files here:
- icon16.png (16x16)
- icon32.png (32x32)
- icon48.png (48x48)
- icon128.png (128x128)

## Design

Use the Context Bridge gradient:
- Colors: #F5A623 → #FF1D6C → #9C27B0 → #2979FF
- Style: Modern, minimal
- Symbol: Bridge or document icon

## Generate

You can use any design tool or online icon generator.

Quick option: Use Favicon.io or similar to create from text "CB" or bridge emoji 🌉
